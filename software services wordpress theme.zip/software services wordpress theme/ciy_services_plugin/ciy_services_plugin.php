<?php
/**
 * @package ciy_services_plugin
 * Plugin Name: CIY Services Plugin
 * Description: An easy way to add services you offer your clients.
 * Author: Shingirai Bhengesa
 * Version: 1.0.0
 * Text Domain: ciy_services_plugin
 */

if(!defined('ABSPATH'))
{
    exit();
}

require_once plugin_dir_path(__FILE__) . 'functions.php';