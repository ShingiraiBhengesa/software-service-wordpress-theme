<?php
/**
 * @package ciy_software_services_theme
 * 
 * Dashboard and backend function
 */

add_theme_support('post-thumbnails');