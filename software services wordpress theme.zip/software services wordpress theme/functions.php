<?php
/**
 * @package ciy_software_services_theme
 * 
 * Include all external files here
 */

require get_template_directory() . '/inc/enqueue.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/dashboard-functions.php';
require get_template_directory() . '/inc/menus.php';