<?php
/**
 * @package ciy_client_manager
 * 
 * Plugin Name: CIY Easy CLient Manager
 * Description: Add clients to your site
 * Version: 1.0.0
 * Author: The Code It Yourself Guy
 * Text Domain: ciy_client_manager
 */

if(!defined('ABSPATH'))
{
    exit;
}

require_once plugin_dir_path(__FILE__) . 'functions.php';