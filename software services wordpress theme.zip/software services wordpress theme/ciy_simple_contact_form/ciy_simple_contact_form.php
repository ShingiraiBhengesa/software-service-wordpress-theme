<?php
/**
 * @package ciy_simple_contact_form
 * Plugin Name: CIY Simple Contact Form
 * Description: A simple contact form to collect emails and messages
 * Version: 1.0.0
 * Author: Shingirai Bhengesa
 * Text Domain: ciy_simple_contact_form
 */
if(!defined('ABSPATH'))
{
    exit;
}

require_once plugin_dir_path(__FILE__) . 'functions.php';