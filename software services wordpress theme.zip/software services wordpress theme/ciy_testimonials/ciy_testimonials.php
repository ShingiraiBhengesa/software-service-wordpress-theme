<?php
/**
 * @package ciy_testimonials_manager
 * Plugin Name: CIY Easy Testimonials Posts
 * Description: Add Testimonials to your site.
 * Version: 1.0.0
 * Author: Shingirai Bhengesa
 * Text Domain: ciy_testimonials_manager
 */
if(!defined('ABSPATH'))
{
    exit;
}

require_once plugin_dir_path(__FILE__) . 'functions.php';